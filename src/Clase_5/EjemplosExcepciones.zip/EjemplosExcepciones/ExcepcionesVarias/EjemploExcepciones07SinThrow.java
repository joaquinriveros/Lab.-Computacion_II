package Excepciones1.ExcepcionesVarias;

public class EjemploExcepciones07SinThrow {
  public static void main(String[] args) {
    System.out.println("Inicio");
    System.out.println(1 / 0);
  }
}
