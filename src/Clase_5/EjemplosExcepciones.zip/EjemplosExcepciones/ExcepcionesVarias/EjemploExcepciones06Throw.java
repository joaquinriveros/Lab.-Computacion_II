package Excepciones1.ExcepcionesVarias;

public class EjemploExcepciones06Throw {
  public static void main(String[] args) {

    System.out.println("Inicio");

    throw new ArithmeticException();
  }
}
