package Gato;

public class ApareamientoNoPosibleException extends Exception {
    public ApareamientoNoPosibleException(String string) {

        super(string);
    }
}
